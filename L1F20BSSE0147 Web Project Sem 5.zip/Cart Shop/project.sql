-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2023 at 08:05 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `email` text NOT NULL,
  `name` text NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`email`, `name`, `feedback`) VALUES
('heera10@gmail.com', 'ali', 'fdhfdh');

-- --------------------------------------------------------

--
-- Table structure for table `myusers`
--

CREATE TABLE `myusers` (
  `userID` int(10) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `myusers`
--

INSERT INTO `myusers` (`userID`, `email`, `password`) VALUES
(0, 'ameer@gmail.com', '$2y$10$uG8qjX3lhTUvZiiYnl7DHOC.UJJJPZDuNSiqY7zvzulOMnQNa40pu'),
(0, '', '$2y$10$fyUxizA28SAOi3esYEPIo.5MxGU8jE.ARmDpwBoZFqbidf1dCMvQK'),
(0, '', '$2y$10$GM2Eanniwe0mdIulAbhaV.k56fEEs7WQfENmNUIX2m//0bFf15Twa'),
(0, '576798657', '$2y$10$ff8GogsbAGcuBeaCoFW4X.3nwHjRqZlv/l3AwF63tSfXyE7R3P4aq'),
(87965, 'heera10@gmail.com', '$2y$10$Z3FGrxMtS43ijXZepC5C/e8IkmVeu5ekdWN0ot.G46p1IPNdtjd6a');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
