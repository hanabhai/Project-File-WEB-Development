<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Bookit | Your Cart</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="Header">
    <div class="container">
        <div class="navbar">
            <div class="logo">
                  <a href="index.html"><img src="images/clickstore.png" alt="" width="125px"></a>
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="ourproducts.php">Products</a></li>
                    <li><a href="">Contact</a></li>
                    <li><a href="">About Us</a></li>
                    <li><a href=""></a></li>
                    <li><a href="account.php"><button class="btn-2">Account</button></a></li>
                </ul>
            </nav>
           <a href="cart.html"><img src="images/cart.png" alt="" width="35px" height="40px"></a> 
           </div>
    </div>
    </div>
<!--Feedback session-->        
     <div class="small-container">
            <div class="row">
                <form action="feedbackdata.php"method="POST" >
                 <table class="tble">
                    <th>
                       <h2> Share Your Experience with us</h2>
                    </th>
                    <tr>
                        <td>Name:</td>
                        <td>
                        <input type="text" placeholder="Enter your Name" required name="name" id="name"value=<?php  if(isset($_GET['name'])) echo $_GET['name']; ?>>
                    </td>
                    </tr>
                    <tr>
                        <td>Email Address:</td>
                        <td>
                        <input type="email" placeholder="Enter your Name" name="email" id="email" required value=<?php  if(isset($_GET['email'])) echo $_GET['email']; ?>>
                    </td>
                    </tr>
                    </tr>
                    <tr>
                      <td>
                        <h5>Feedback</h5>
                        </td><td>
                        <textarea  placeholder="Enter your Feedback" name="feedback" id="feedback" rows="10px" cols="25px" style="font-size: 15px;" required></textarea>
                      </td>
                    </tr>
                    <?php 
                     if(!isset($_GET['feedback']))
                                       {
                                          echo "
                                         <tr>
                                         <td colspan='2'>
                                         <button type='submit' class='btn-3' name='submit' value='Submit'>Submit</button>
                                         </td>
                                         </tr>";
                                       }
                    ?>
                 </table>
                </form>
            </div>
     </div>   
<!---Next Session-->
    <footer>
        <div class="small-container">
            <p>Copyright &copy; 2023</p>
            <ul>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
            <p>Follow us on:</p>
            <div class="col-img">
                <ul>
                    <li><a href="https://web.facebook.com/login/?_rdc=1&_rdr"><img src="images/facebook.png" alt=""></a>
                    </li>
                    <li><a href="https://www.instagram.com/accounts/login/"><img src="images/insta.png" alt=""></a></li>
                </ul>
            </div>
    
        </div>
    </footer>
    <!--Script for footer-->
    <script>
        const currentYear = new Date().getFullYear();
        const copyright = document.querySelector("footer p");
        copyright.innerHTML = `Copyright &copy; ${currentYear}`;
    </script>

  
</body>
</html>