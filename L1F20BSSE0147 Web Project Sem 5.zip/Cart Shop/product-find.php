<?php
//connect to the database
include 'db-conn.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $name = $_POST['name'];
    $price = $_POST['price'];
    $sale = $_POST['sale'];
   // echo "Email:" .$email . " Username :" . $username . "Password :" . $password;
    // Check connection
    $conn = createConnection();
    if (!$conn) {
        die("Connection failed: ");
    }
    //if the register form is submitted
        // insert the data into the database
        if (isset($_POST['submit'])) {
      $stmt=$conn->prepare( " INSERT INTO sale(name, price, sale) 
         VALUES ('$name', '$price', '$sale')");
        if ($stmt->execute()) {
            echo "New record created successfully";
            header('location:ourproducts.php');
        }
    } elseif (isset($_POST['delete'])) {
         $stmt=$conn->prepare( "DELETE  from sale where $name='name'");
    }     
      else {
            echo "Error: " . $sql . "<br>";
        }

    // close the connection
    $conn->close();
}
?>
