<?php
//connect to the database
include 'db-conn.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $email = $_POST['email'];
    $userID = $_POST['userID'];
    $password = $_POST['password'];
    echo "Email:" .$email . " UserID :" . $UserID . "Password :" . $password;
    // Check connection
    $conn = createConnection();
    if (!$conn) {
        die("Connection failed: ");
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    //if the register form is submitted
        // insert the data into the database
         $sql = "SELECT * FROM myusers WHERE UserID='$userID' or email = '$email'";
         $result = $conn->query($sql);
         $row = $result->fetch_assoc();

    if ($result->num_rows > 0)
         {
              echo "Email already exists. Please use a different email.";
        header('location:account.php');
        exit();
    }
    else{    
            $stmt=$conn->prepare( "INSERT INTO myusers (email, userID, password)
         VALUES ( '$email','$userID', '$hashed_password')");
        if ($stmt->execute()) {
            echo "New record created successfully";
            header('location:index.html');
        } else {
            echo "Error: " . $sql . "<br>";
        }
        
         }


    // close the connection
    $conn->close();
}
?>
