<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Bookit | Your Cart</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="Header>
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/clickstore.png" alt="" width="125px">
                </div>
                <nav>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li><a href="ourproducts.php">Products</a></li>
                        <li><a href="">Contact</a></li>
                        <li><a href="">About Us</a></li>
                        <li><a href=""></a></li>
                        <li><a href="account.html"><button class="btn-2">Account</button></a></li>
                    <a href="viewlogins.php"><button type='submit' class='btn-2'>ViewLogins</button></a>
                    </ul>
                </nav>
                <img src="images/cart.png" alt="" width="35px" height="40px">
            </div>
        </div>
    </div>
    <!--Account Page-->
    <div class="Header_2">
    <div class="account-page">
        <div class="container">
            <div class="row">
                  <div class="form-container">
                    <div class="form-btn">
                        <span onclick="login()">login</span>
                        <span onclick="register()">Register</span>
                        <hr id="indecator">
                    </div>
                    <form action="userdata.php"method="POST" id="loginform">
                        <table class="tablelogin">
                            <tr>
                                <td>
                                    <input type="text"Placeholder="Enter Your ID" name="userID"id="userID"required value=<?php  if(isset($_GET['userID'])) echo $_GET['userID']; ?> >;
                                </td>
                            </tr>
                                <?php 
                               if(!isset($_GET['email']))
                                {
                                       echo "
                                       <tr>
                                       <td><input type='password' name='password' id='password' placeholder='Enter the password...'></td>
                                        </tr>";
                                 }
                                 ?>
                                 <?php 
                                    if(!isset($_GET['email']))
                                       {
                                          echo "
                                         <tr>
                                         <td colspan='2'>
                                         <button type='submit' class='btn' value='Register'> Login</button>
                                         </td>
                                         </tr>";
                                       }
                                    else
                                       {
                                           echo "<tr>
                                          <td><input type='submit' value='Update'></td>
                                          <td><input type='submit' value='Cancel'></td>
                                          </tr>";
                                       }
                                        ?>
                            <td>
                                 <a href="" style="font-weight: bold;">Forgotten Password</a>
                        </tr>
                       
                        </table>
                        
                        
                    </form>
                    <form action="userdata.php"method="post"id="Registerform">
                        <table>
                            <tr>
                                <td>
                                    <input type="email" Placeholder="Email" name="email"id="email" required>;
                                </td>
                            </tr>
                            <tr>
                                <td>
                            <input type="text" Placeholder="UserID" name="userID"id="userID"required>;
                                </td>
                            </tr>
                            <tr>
                                <td>
                            <input type="password" Placeholder="Password" name="password"id="password"required>
                                </td>
                            </tr>
                            <tr>
                                    <td colspan='2'>
                                         <button type='submit' class='btn' value='Register'>Register</button>
                                    </td>
                            </tr>
                        </table>
                        
                    </form>

                  </div>
            </div>
        </div>
    </div>
    </div>
    <footer>
        <div class="small-container">
            <p>Copyright &copy; 2023</p>
            <ul>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
            <p>Follow us on:</p>
            <div class="col-img">
                <ul>
                <li><a href="https://web.facebook.com/login/?_rdc=1&_rdr"><img src="images/facebook.png" alt=""></a></li>
                <li><a href="https://www.instagram.com/accounts/login/"><img src="images/insta.png" alt=""></a></li>
            </ul>
            </div>
            
        </div>
    </footer>
    <!--Script for footer-->
    <script>
            const currentYear = new Date().getFullYear();
            const copyright = document.querySelector("footer p");
            copyright.innerHTML = `Copyright &copy; ${currentYear}`;
    </script>


    <!--Script of JS for form-->
    <script>
        var loginform=document.getElementById("loginform");
        var Registerform = document.getElementById("Registerform");
        var indecator = document.getElementById("indecator");

        function register()
        {
            loginform.style.transform="translateX(0px)";
            Registerform.style.transform = "translateX(0px)";
            indecator.style.transform = "translateX(100px)";
        }
        function login() {
                loginform.style.transform = "translateX(300px)";
                Registerform.style.transform = "translateX(300px)";
                indecator.style.transform = "translateX(0px)";
                console.log(onclick=login("your account has logged in"));
            }
    </script>
</body>
</html>