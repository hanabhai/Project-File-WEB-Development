<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Bookit | Your Cart</title>
    <link rel="stylesheet" href="style.css">
    <script src="limit.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="Header">
    <div class="container">
        <div class="navbar">
            <div class="logo">
                  <img src="images/clickstore.png" alt="" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="ourproducts.php">Products</a></li>
                    <li><a href="">Contact</a></li>
                    <li><a href="">About Us</a></li>
                    <li><a href=""></a></li>
                    <li><a href="account.php"><button class="btn-2">Account</button></a></li>
                </ul>
            </nav>
            <img src="images/cart.png" alt="" width="35px" height="40px">
           </div>
    </div>
</div>

<div class="category"> 
    <div class="small-container">
        
        <div class="row row-2">
            <h2>All Products</h2>
            <select name="" id="">
                <option value="">Defalt Sorting</option>
                <option value="">Sort by Price</option>
                <option value="">Sort By Popularity</option>
                <option value="">Sort by Sale</option>
                <option value="">Sort by rating</option>
            </select>
        </div>
        <!---Form next -->
    <div class="small-container ">
        <table class="tableh">
            <tr>
                <td>
            <div class="row">
            <div class=" col-3">
            <img src="images-producs/add-s-3.jpeg" alt="Product 1">
            <div class="product-name">Product 1</div>
            <div class="product-price">$100</div>
            <button class="btn-f" onclick="addToCart('Product 1', 102)">Add to Cart</button>
          </div>
          </div>
                </td>
                <td>
            <div class="row">
             <div class="col-3">
            <img src="images-producs/add-s-1.jpg" alt="Product 2">
            <div class="product-name">Product 2</div>
            <div class="product-price">$310</div>
            <button class="btn-f">Add to Cart</button>
           </div>
           </div>
                </td>
                    <td>
            <div class="row">
             <div class="col-3">
            <img src="images-producs/add-s-1.jpg" alt="Product 2">
            <div class="product-name">Product 3</div>
            <div class="product-price">$310</div>
            <button class="btn-f "onclick="addToCart('Product 2', 100)">Add to Cart</button>
           </div>
           </div>
                </td>
                    <td>
            <div class="row">
             <div class="col-3">
            <img src="images-producs/add-s-1.jpg" alt="Product 2">
            <div class="product-name">Product 4</div>
            <div class="product-price">$310</div>
            <button class="btn-f">Add to Cart</button>
           </div>
           </div>
                </td>
            </tr>
             <tr>
                <td>
            <div class="row">
            <div class=" col-3">
            <img src="images-producs/add-s-3.jpeg" alt="Product 1">
            <div class="product-name">Product 5</div>
            <div class="product-price">$100</div>
            <button class="btn-f">Add to Cart</button>
          </div>
          </div>
                </td>
                <td>
            <div class="row">
             <div class="col-3">
            <img src="images-producs/add-s-1.jpg" alt="Product 2">
            <div class="product-name">Product 6</div>
            <div class="product-price">$310</div>
            <button class="btn-f">Add to Cart</button>
           </div>
           </div>
                </td>
                    <td>
            <div class="row">
             <div class="col-3">
            <img src="images-producs/add-s-1.jpg" alt="Product 2">
            <div class="product-name">Product 8</div>
            <div class="product-price">$310</div>
            <button class="btn-f ">Add to Cart</button>
           </div>
           </div>
                </td>
                    <td>
            <div class="row">
             <div class="col-3">
            <img src="images-producs/add-s-1.jpg" alt="Product 2">
            <div class="product-name">Product 7</div>
            <div class="product-price">$310</div>
            <button class="btn-f">Add to Cart</button>
           </div>
           </div>
                </td>
            </tr>
        </table>
        </div>
        </div>  
    </div>
         

<!--Ending-->
    <footer>
        <div class="small-container">
            <p>Copyright &copy; 2023</p>
            <ul>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
            <p>Follow us on:</p>
            <div class="col-img">
                <ul>
                    <li><a href="https://web.facebook.com/login/?_rdc=1&_rdr"><img src="images/facebook.png" alt=""></a>
                    </li>
                    <li><a href="https://www.instagram.com/accounts/login/"><img src="images/insta.png" alt=""></a></li>
                </ul>
            </div>
    
        </div>
    </footer>
    <!--Script for footer-->
    <script>
        const currentYear = new Date().getFullYear();
        const copyright = document.querySelector("footer p");
        copyright.innerHTML = `Copyright &copy; ${currentYear}`;
    </script>
    <!--Script for data showing-->
    <script src="limit.js"></script>
</body>
</html>