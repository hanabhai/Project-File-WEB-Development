<?php
//connect to the database
include 'db-conn.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $email = $_POST['email'];
    $name = $_POST['name'];
    $feedback = $_POST['feedback'];
    echo "Email:" .$email . " name :" . $name. "Password :" . $feedback;
    // Check connection
    $conn = createConnection();
    if (!$conn) {
        die("Connection failed: ");
    }
  
        $stmt=$conn->prepare( "INSERT INTO feedback (email, name, feedback)
         VALUES ( '$email','$name', '$feedback')");
        if ($stmt->execute()) {
            echo "New record created successfully";
            header('location:index.html');
        } else {
            echo "Error: " . $sql . "<br>";
        }


    // close the connection
    $conn->close();
}
?>
