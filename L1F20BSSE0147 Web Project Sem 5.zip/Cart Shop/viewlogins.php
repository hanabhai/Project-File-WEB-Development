<?php

include 'db-conn.php';
$conn = createConnection();
echo "<link rel='stylesheet' href='style.css'>";
$query = "SELECT * from myusers";
$result = $conn->query($query);
if($result->num_rows>0)
{
    echo "<table>
        <tr>
            <th>UserID</th>
            <th>email</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>";
    
    while($row = $result->fetch_assoc())
    {
        echo "<tr>
                    <td>".$row['userID']."</td>
                    <td>".$row['email']."</td>
                    <td>
                       <Form method='post'>
                            <input type='hidden' value=".$row['userID']." name='UserID'>
                            <input type='hidden' value=".$row['email']." name='email'>
                            <input type='submit' value='Update' name='btnUpdate'>
                        </Form> 
                    </td>
                    <td>
                    <Form method='post'>
                         <input type='hidden' value=".$row['userID']." name='UserID'>
                           <input type='submit' value='Delete' name='btnDelete'>
                        </Form>
                    </td>
            </tr>";
    }
    
    echo "</table>";
}
 

if(isset($_POST['btnDelete']))
{   
     $query = "DELETE from myusers where userID=".$_POST['userID'];
    if($conn->query($query))
    {
        echo "Record Deleted Successfully.<br>";
        header("Location:viewlogins.php");
    }
}



if(isset($_POST['btnUpdate']))
{
   header("Location:account.php?email=".$_POST['email']."&userID=".$_POST['userID']);
}
$conn->close();

?>