
function addToCart(productName, price) {
  let product = {
    name: productName,
    price: price
  };
  carts.push(product);
  updateCartTable();
}

function updateCartTable() {
  let table = document.getElementById("carts");
  table.innerHTML = `
    <tr>
      <th>Product Name</th>
      <th>Price</th>
    </tr>
  `;
  for (let i = 0; i < carts.length; i++) {
    table.innerHTML += `
      <tr>
<td>${carts[i].name}</td>
<td>$${carts[i].price}</td>
</tr>
`;
}
}